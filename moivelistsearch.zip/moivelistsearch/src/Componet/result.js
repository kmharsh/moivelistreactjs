import React from 'react'

function Result({ result , openpopup}) {

    return (
        <div className="results" onClick={()=>openpopup(result.imdbID)}>
            <div className="imgwraper">
            <img src={result.Poster}/>
            </div>
            <h3>{result.Title}</h3>
        </div>
    )
}

export default Result;
