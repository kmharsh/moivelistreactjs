import React from 'react'

function popup({ selected, closepopup }) {
    return (
        <section className="popup">
            <div className="content">
                <div className="plot">
                    <img src={selected.Poster} />
                    <div className="content-details">
                        <h2>{selected.Title} <span>({selected.Year})</span></h2>
                        <p className="rating"> Rating: {selected.imdbRating}</p>
                        <p> Plot:{selected.Plot}</p>
                        <p>Director: {selected.Director}</p>
                        <p> Production:{selected.Production}</p>
                        <p> Actors:{selected.Actors}</p>
                    </div>

                </div>
                <button className="close" onClick={closepopup}> Close</button>

            </div>
        </section>
    )
}

export default popup
