import React from 'react'
import '../../node_modules/font-awesome/css/font-awesome.min.css'
const Search = ({ handleInput , search}) => {
    return (
      <section className="search-section">
        <input type="text"
         name="search"
          placeholder="search moive name..." 
          className="search-box" 
          onChange={handleInput}
          onKeyPress={search}
          />
          <i className="fa fa-search search0icon" aria-hidden="true"></i>
      </section>
    )
}

export default Search
