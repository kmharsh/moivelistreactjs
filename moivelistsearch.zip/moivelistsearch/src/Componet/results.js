import React from 'react'
import Result from './result'
function Results({results, openpopup}) {
    return (
      <section className="result">
          {results.map(result =>(
              <Result key={result.imdbID} result={result} openpopup={openpopup}/>
          ))}
      </section>
    )
}

export default Results;
