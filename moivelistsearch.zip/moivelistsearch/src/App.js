import React ,{useState} from 'react';
import './App.css';
import Search from './Componet/search';
import Axios from 'axios';
import Results from './Componet/results';
import Popup from './Componet/popup';
function App() {
  const [state, setState]=useState({
  s:"",
  results:[],
  selected:{},
  });
  const apiUrl= "http://www.omdbapi.com/?apikey=cc18f75";
  const search =(e)=>{
    if (e.key === "Enter"){
      Axios (apiUrl + "&s="+ state.s).then(({data})=>{
        let results= data.Search;
         setState(prevState=>{
           return{...prevState ,results:results}
         })
      });
    }
  }

  const handleInput =(e)=>{
    let s = e.target.value;
    setState(prevState =>{
      return{
        ...prevState,s: s
      }
    });
  }
  const openpopup = async ( id ) =>{
    console.log("id", id);
   let data = await Axios (apiUrl + "&i="+ id ).then(({data})=>{     
      return data;
    });
    console.log("popup",data);
    setState(prevState=>{
      return{...prevState, selected: data }
    });
  }
  const closepopup =()=>{
    setState(prevState=>{
      return{...prevState, selected: {} }
    });
  }
  return (
    <div className="App">
      <header>
        <h1>Moive DashBorad</h1>
      </header>
      <main>
        <Search handleInput={handleInput} search={search}/>
        <Results results={state.results} openpopup={openpopup}/>

        {(typeof state.selected.Title !="undefined") ?<Popup selected={state.selected} 
        closepopup={closepopup}/>:false}
      </main>
    </div>
  );
}

export default App;
